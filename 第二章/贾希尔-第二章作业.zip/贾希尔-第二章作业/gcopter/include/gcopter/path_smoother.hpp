#ifndef PATH_SMOOTHER_HPP
#define PATH_SMOOTHER_HPP

#include "cubic_spline.hpp"
#include "lbfgs.hpp"

#include <Eigen/Eigen>

#include <cmath>
#include <cfloat>
#include <iostream>
#include <vector>

namespace path_smoother
{

    class PathSmoother
    {
    private:
        cubic_spline::CubicSpline cubSpline;

        int pieceN;
        Eigen::Matrix3Xd diskObstacles;
        double penaltyWeight;
        Eigen::Vector2d headP;
        Eigen::Vector2d tailP;
        Eigen::Matrix2Xd points;
        Eigen::Matrix2Xd gradByPoints;

        lbfgs::lbfgs_parameter_t lbfgs_params;

    private:
        static inline double costFunction(void *ptr,
                                          const Eigen::VectorXd &x,
                                          Eigen::VectorXd &g)
        {
            // Hints:This is a function which define the costfunction, you can use
            // the content which *ptr point to initialize a quote of Class:
            // PathSmoother, the you can use the quote to visit the cubSpline
            // TODO
            auto instance = reinterpret_cast<path_smoother::PathSmoother *>(ptr);
            const int points_num = instance->pieceN - 1;
            double cost = 0.0;
            Eigen::Matrix2Xd grad;
            grad.resize(2, points_num);
            grad.setZero();

            //用指针调用cubicspline对象中的函数得到energy的值和梯度值
            Eigen::Matrix2Xd inPs;
            inPs.resize(2, points_num);
            inPs.setZero();
            //x一列数据存到两行
            inPs.row(0) = x.head(points_num);
            inPs.row(1) = x.tail(points_num);
            instance->cubSpline.setConditions(instance->headP, instance->tailP, points_num+1);
            instance->cubSpline.setInnerPoints(inPs);

            double energy = 0.0;
            Eigen::Matrix2Xd energy_grad;
            energy_grad.resize(2, points_num);
            energy_grad.setZero();
            instance->cubSpline.getStretchEnergy(energy);
            instance->cubSpline.getGrad(energy_grad);
            cost += energy;
            grad += energy_grad;

            //计算碰撞函数和梯度
            double potential = 0.0;
            Eigen::Matrix2Xd potential_grad;
            potential_grad.resize(2, points_num);
            potential_grad.setZero();
            //i是插点数的索引，j是障碍物的索引
            for (int i = 0; i < points_num; i++)
            {
                for (int j = 0; j < instance->diskObstacles.cols(); j++)
                {
                    double distance = (inPs.col(i) - instance->diskObstacles.col(j).head(2)).norm();

                    if (instance->diskObstacles(2,j) > distance)
                    {
                        potential += (instance->diskObstacles(2, j) - distance) * instance->penaltyWeight;
                        potential_grad.col(i) += -instance->penaltyWeight * 
                        (inPs.col(i) - instance->diskObstacles.col(j).head(2))/distance;
                        
                    }
                }
            }

            //energy 和 potential加一起
            cost += potential;
            grad += potential_grad;
            g.setZero();
            //两行变一列
            g.head(points_num) = grad.row(0).transpose();
            g.tail(points_num) = grad.row(1).transpose();

            std::cout << std::setprecision(10)
                      << "-----------------------------------" << std::endl
                      << "插点数: " << points_num << std::endl
                      << "目标函数值: " << cost << std::endl
                      << "梯度值: " << g.cwiseAbs().maxCoeff() << std::endl;
                      

            return cost;
        }

    public:
        inline bool setup(const Eigen::Vector2d &initialP,
                          const Eigen::Vector2d &terminalP,
                          const int &pieceNum,
                          const Eigen::Matrix3Xd &diskObs,
                          const double penaWeight)
        {
            pieceN = pieceNum;
            diskObstacles = diskObs;
            penaltyWeight = penaWeight;
            headP = initialP;
            tailP = terminalP;

            cubSpline.setConditions(headP, tailP, pieceN);

            points.resize(2, pieceN - 1);
            gradByPoints.resize(2, pieceN - 1);

            return true;
        }

        inline double optimize(CubicCurve &curve,
                               const Eigen::Matrix2Xd &iniInPs,
                               const double &relCostTol)
        {
            // NOT TODO
            Eigen::VectorXd x(pieceN * 2 - 2);
            Eigen::Map<Eigen::Matrix2Xd> innerP(x.data(), 2, pieceN - 1);
            innerP = iniInPs;

            double minCost;
            lbfgs_params.mem_size = 64;
            lbfgs_params.past = 3;
            lbfgs_params.min_step = 1.0e-32;
            lbfgs_params.g_epsilon = 0.0;
            lbfgs_params.delta = relCostTol;

            int ret = lbfgs::lbfgs_optimize(x,
                                            minCost,
                                            &PathSmoother::costFunction,
                                            nullptr,                                          
                                            this,
                                            lbfgs_params);

            if (ret >= 0)
            {
                //cubSpline.setInnerPoints(innerP);
                cubSpline.getCurve(curve);
            }
            else
            {
                curve.clear();
                minCost = INFINITY;
                std::cout << "Optimization Failed: "
                          << lbfgs::lbfgs_strerror(ret)
                          << std::endl;
            }

            return minCost;
        }
    };

}

#endif
