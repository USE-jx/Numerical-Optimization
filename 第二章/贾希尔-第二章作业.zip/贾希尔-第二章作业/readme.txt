程序运行：

1 创建一个工作空间

2 将gcopter文件夹放入工作空间下的src下

3 在工作空间路径下终端输入catkin_make

4 source devel/setup.bash

5 roslaunch gcopter curve_gen.launch

6 出现rviz界面，有几个红色圆柱形障碍物

7 点击2D Goal，然后在图中点两下设置起始点和目标点即可产生一条无碰撞轨迹。
